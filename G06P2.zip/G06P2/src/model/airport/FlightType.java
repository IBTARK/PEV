package model.airport;

public enum FlightType {
	W, G, P;
}
