package model.mutation;

import model.chromosomes.Chromosome;

public interface Mutation {
	
	public void mutate(Chromosome c);
}
