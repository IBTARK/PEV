package view.auxPanels;

import javax.swing.JPanel;

public class RightPanel extends JPanel{

}
